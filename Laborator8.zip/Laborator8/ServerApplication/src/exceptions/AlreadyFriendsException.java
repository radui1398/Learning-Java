package exceptions;

public class AlreadyFriendsException extends Exception {
    public AlreadyFriendsException(){super();}
}
