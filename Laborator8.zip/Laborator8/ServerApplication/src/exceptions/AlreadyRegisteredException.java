package exceptions;

public class AlreadyRegisteredException extends Exception{

    public AlreadyRegisteredException(){ super();};
}