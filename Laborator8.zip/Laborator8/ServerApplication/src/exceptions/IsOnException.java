package exceptions;

public class IsOnException extends Exception {
    public IsOnException(){super();}
}
